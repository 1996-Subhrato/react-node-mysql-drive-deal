import React from 'react';

const Login = () => {
  return (
    <div>
      <h1>Login Page</h1>
      <p>Login form placeholder.</p>
    </div>
  );
};

export default Login;
